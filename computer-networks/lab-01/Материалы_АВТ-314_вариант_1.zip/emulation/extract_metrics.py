from scapy.all import rdpcap,BOOTP,DHCP,UDP,TCP,ICMP,IP
from pathlib import Path
import json
p=Path('/lab/evidence');m={}
for f in p.glob('*.pcap'):
 packets=rdpcap(str(f));rows=[]
 for a in packets:
  if DHCP in a:
   opt=dict(x for x in a[DHCP].options if isinstance(x,tuple))
   rows.append(dict(kind='dhcp',xid=hex(a[BOOTP].xid),msg=opt.get('message-type'),giaddr=a[BOOTP].giaddr,yiaddr=a[BOOTP].yiaddr,src=a[IP].src,dst=a[IP].dst,sport=a[UDP].sport,dport=a[UDP].dport,server_id=str(opt.get('server_id','')),lease=opt.get('lease_time'),mask=str(opt.get('subnet_mask','')),router=str(opt.get('router',''))))
  elif TCP in a:
   rows.append(dict(kind='tcp',src=a[IP].src,dst=a[IP].dst,sport=a[TCP].sport,dport=a[TCP].dport,flags=str(a[TCP].flags),seq=a[TCP].seq,ack=a[TCP].ack,payload=len(bytes(a[TCP].payload))))
  elif ICMP in a:
   rows.append(dict(kind='icmp',src=a[IP].src,dst=a[IP].dst,type=a[ICMP].type,code=a[ICMP].code,ttl=a[IP].ttl))
  elif UDP in a:
   rows.append(dict(kind='udp',src=a[IP].src,dst=a[IP].dst,sport=a[UDP].sport,dport=a[UDP].dport,payload=len(bytes(a[UDP].payload))))
 m[f.stem]=dict(frames=len(packets),rows=rows)
assert [x['msg'] for x in m['01-dhcp']['rows'] if x['kind']=='dhcp']==[1,2,3,5]
assert any(x.get('kind')=='icmp' and x['type']==3 and x['code']==3 for x in m['08-udp-closed']['rows'])
assert any(x.get('kind')=='tcp' and 'R' in x['flags'] for x in m['10-tcp-closed']['rows'])
for k in ['02-ping-local','04-ping-gateway','05-ping-remote','06-ping-wifi']:
 assert len([x for x in m[k]['rows'] if x['kind']=='icmp' and x['type']==0])==3,k
Path('/lab/evidence_metrics.json').write_text(json.dumps(m,indent=2))
print('PCAP verified:',len(m),'captures')
print(json.dumps(m['01-dhcp'],indent=2));print(json.dumps(m['10-tcp-closed'],indent=2))
