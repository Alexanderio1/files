"""Transparent 802.1Q adapter for kernels without VLAN virtual interfaces.

Usage: vlan_mux.py TRUNK VID:UNTAGGED_IFACE [VID:UNTAGGED_IFACE ...]
The router's IP, ARP and forwarding remain in the Linux network stack.
"""
import socket, select, struct, sys

trunk = sys.argv[1]
ports = {int(p.split(':')[0]):p.split(':')[1] for p in sys.argv[2:]}
interfaces = [trunk] + list(ports.values())
sockets = {}
for interface in interfaces:
    sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(3))
    sock.bind((interface, 0))
    sock.setsockopt(263, 8, 1)  # SOL_PACKET / PACKET_AUXDATA (VLAN offload metadata)
    sockets[interface] = sock
by_socket = {s:i for i,s in sockets.items()}
by_interface = {p:v for v,p in ports.items()}
while True:
    for sock in select.select(list(by_socket), [], [])[0]:
        frame, control, flags, meta = sock.recvmsg(65535,1024)
        if meta[2] == socket.PACKET_OUTGOING or len(frame) < 14:
            continue
        for level, kind, data in control:
            if level == 263 and kind == 8 and len(data) >= 20:
                status, length, snaplen, macoff, netoff, tci, tpid = struct.unpack('IIIHHHH',data[:20])
                if status & 16 and frame[12:14] != b'\x81\x00':
                    frame = frame[:12] + struct.pack('!HH',tpid if status & 64 else 0x8100,tci) + frame[12:]
        source = by_socket[sock]
        if source == trunk:
            if frame[12:14] != b'\x81\x00' or len(frame) < 18:
                continue
            vid = struct.unpack('!H',frame[14:16])[0] & 0x0fff
            if vid in ports:
                sockets[ports[vid]].send(frame[:12] + frame[16:])
        else:
            sockets[trunk].send(frame[:12] + struct.pack('!HH',0x8100,by_interface[source]) + frame[12:])
