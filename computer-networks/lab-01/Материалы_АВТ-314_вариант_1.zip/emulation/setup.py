import json, subprocess, urllib.request, uuid, time, os
from pathlib import Path

ROOT = Path('/lab')
BASE = 'http://127.0.0.1:3080/v2'
PROJECT = str(uuid.uuid4())

def api(path, data=None, method=None):
    req = urllib.request.Request(BASE + path, data=None if data is None else json.dumps(data).encode(), headers={'Content-Type':'application/json'}, method=method)
    try:
        r = urllib.request.urlopen(req, timeout=30)
        b = r.read()
        return json.loads(b) if b else None
    except urllib.error.HTTPError as e:
        raise RuntimeError(f'{path}: {e.code}: {e.read().decode()}')

def run(*args, check=True):
    return subprocess.run(args, check=check, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout

def ns(name, *args):
    return run('nsenter','--net=/run/netns/'+name,*args)

vlans = [
    (102,'192.168.100.1/26'),(104,'192.168.100.65/26'),
    (119,'192.168.100.129/26'),(120,'192.168.100.193/26'),
    (20,'192.168.101.1/26'),(50,'192.168.101.65/27'),
    (99,'192.168.101.97/27'),(40,'192.168.101.129/28'),
    (30,'192.168.101.145/28')]

specs = []
def host(name, sw, port, vlan, address, gw, pos, dhcp=False):
    specs.append(dict(name=name,sw=sw,port=port,vlan=vlan,address=address,gw=gw,x=pos[0],y=pos[1],dhcp=dhcp))

switch_pos={'CORE':(0,-230),'SW502':(-560,-40),'SW504':(-180,-40),'SW508':(220,-40),'SW519':(-560,360),'SW520':(-180,360),'SW511':(220,360)}
for room,sw,vlan,base,x,y,pi in [(502,'SW502',102,0,-560,-40,146),(504,'SW504',104,64,-180,-40,147),(519,'SW519',119,128,-560,360,148),(520,'SW520',120,192,-180,360,149)]:
    host(f'PC{room}A',sw,0,vlan,f'192.168.100.{base+10}/26',f'192.168.100.{base+1}',(x-100,y+130),True)
    host(f'PC{room}B',sw,1,vlan,f'192.168.100.{base+2}/26',f'192.168.100.{base+1}',(x,y+130))
    host(f'PRN{room}',sw,2,30,f'192.168.101.{pi}/28','192.168.101.145',(x+100,y+130))
host('PC506','SW508',0,20,'192.168.101.10/26','192.168.101.1',(120,90),True)
host('PC507','SW508',1,20,'192.168.101.11/26','192.168.101.1',(220,90),True)
host('PRN508','SW508',2,30,'192.168.101.150/28','192.168.101.145',(320,90))
host('PC510','SW511',0,20,'192.168.101.12/26','192.168.101.1',(70,490),True)
host('DHCP1','SW511',1,40,'192.168.101.130/28','192.168.101.129',(170,490))
host('APP1','SW511',2,40,'192.168.101.131/28','192.168.101.129',(270,490))
host('PRN510','SW511',3,30,'192.168.101.151/28','192.168.101.145',(370,490))


for old in api('/projects'):
    if old['name'].startswith('AVT-314 Lab1'):
        api('/projects/'+old['project_id'],{'name':'Draft-'+old['project_id'][:8]},'PUT')
        api('/projects/'+old['project_id']+'/close',{},'POST')
for old in run('ip','netns','list').splitlines():
    run('ip','netns','del',old.split()[0])
api('/projects',dict(project_id=PROJECT,name='AVT-314 Lab1 V1 VT 172 nodes',auto_close=False,path='/root/GNS3/projects/'+PROJECT))
api(f'/projects/{PROJECT}/open',{},'POST')
nodes={}; links=[]; interfaces={}

def node(name, typ, x, y, properties, symbol):
    n=api(f'/projects/{PROJECT}/nodes',dict(name=name,node_type=typ,compute_id='local',x=x,y=y,properties=properties,symbol=symbol))
    nodes[name]=n
    return n

for sw,(x,y) in switch_pos.items():
    if sw=='CORE':
        ports=[dict(name=f'Te{i+1}',port_number=i,type='dot1q',vlan=1) for i in range(7)]
    else:
        ports=[dict(name=f'Gi{i+1}',port_number=i,type='access',vlan=next(s['vlan'] for s in specs if s['sw']==sw and s['port']==i)) for i in range(4 if sw=='SW511' else 3)]
        ports.append(dict(name='Te1',port_number=(4 if sw=='SW511' else 3),type='dot1q',vlan=1))
        if sw in ['SW502','SW519']: ports.append(dict(name='AP',port_number=4,type='dot1q',vlan=1))
    node(sw,'ethernet_switch',x,y,dict(ports_mapping=ports),':/symbols/ethernet_switch.svg')

counter=0
def cloud(name,x,y,count=1,symbol=':/symbols/computer.svg'):
    global counter
    counter+=1
    run('ip','netns','add',name)
    ns(name,'ip','link','set','lo','up')
    ps=[]
    for p in range(count):
        a=f'v{counter}p{p}'; b=f'n{counter}p{p}'
        run('ip','link','add',a,'type','veth','peer','name',b)
        run('ip','link','set',b,'netns',name)
        ns(name,'ip','link','set',b,'name',f'eth{p}')
        ns(name,'ip','link','set',f'eth{p}','address',f'02:07:01:00:{counter:02x}:{p:02x}')
        ns(name,'ip','link','set',f'eth{p}','up')
        run('ip','link','set',a,'up')
        ps.append(dict(name=f'eth{p}',port_number=p,type='ethernet',interface=a))
        interfaces[(name,p)]=a
    return node(name,'cloud',x,y,dict(ports_mapping=ps),symbol)

def link(a,pa,b,pb):
    obj=api(f'/projects/{PROJECT}/links',dict(nodes=[dict(node_id=nodes[a]['node_id'],adapter_number=0,port_number=pa),dict(node_id=nodes[b]['node_id'],adapter_number=0,port_number=pb)]))
    links.append(dict(a=a,pa=pa,b=b,pb=pb,link_id=obj['link_id']))

for i,sw in enumerate([s for s in switch_pos if s!='CORE']): link('CORE',i,sw,4 if sw=='SW511' else 3)
for s in specs:
    cloud(s['name'],s['x'],s['y'],symbol=':/symbols/server.svg' if s['name'] in ['APP1','DHCP1'] else ':/symbols/computer.svg')
    link(s['sw'],s['port'],s['name'],0)
    if not s['dhcp']:
        ns(s['name'],'ip','addr','add',s['address'],'dev','eth0')
        ns(s['name'],'ip','route','add','default','via',s['gw'])

cloud('R1',0,-370,symbol=':/symbols/router.svg');link('CORE',6,'R1',0)
for vid,addr in vlans:
    ns('R1','ip','link','add',f'q{vid}','type','veth','peer','name',f'r{vid}')
    ns('R1','ip','link','set',f'q{vid}','up')
    ns('R1','ip','link','set',f'r{vid}','up')
    ns('R1','ip','addr','add',addr,'dev',f'r{vid}')
ns('R1','sysctl','-w','net.ipv4.ip_forward=1')

for room,x,y,mgmt,wifi in [(502,-780,-40,105,66),(519,-780,360,106,67)]:
    name=f'AP{room}';cloud(name,x,y,2,symbol=':/symbols/affinity/circle/blue/router_cloud.svg');link(f'SW{room}',4,name,0)
    ns(name,'ip','link','add','q99','type','veth','peer','name','r99')
    for dev in ['q99','r99']:ns(name,'ip','link','set',dev,'up')
    ns(name,'ip','addr','add',f'192.168.101.{mgmt}/27','dev','r99')
    ns(name,'ip','route','add','default','via','192.168.101.97')
    w=f'WIFI{room}';cloud(w,x,y+190)
    air=f'AIR{room}'
    node(air,'ethernet_switch',x-110,y+75,dict(ports_mapping=[dict(name='Radio',port_number=0,type='access',vlan=1),dict(name='Client',port_number=1,type='access',vlan=1)]),':/symbols/affinity/circle/blue/cloud.svg')
    link(name,1,air,0);link(air,1,w,0)
    specs.append(dict(name=w,sw=name,port=1,vlan=50,address=f'192.168.101.{wifi}/27',gw='192.168.101.65',x=x,y=y+130,dhcp=True))

for n in run('ip','netns','list').splitlines():
    n=n.split()[0]
    for d in json.loads(ns(n,'ip','-j','link')):
        if d['ifname']!='lo':
            ns(n,'ethtool','-K',d['ifname'],'tx','off','tso','off','gso','off','gro','off')
api(f'/projects/{PROJECT}/nodes/start',{},'POST')
subprocess.Popen(['nsenter','--net=/run/netns/R1','python','/lab/vlan_mux.py','eth0']+[f'{v}:q{v}' for v,a in vlans],stdout=open('/lab/mux-r1.log','w'),stderr=subprocess.STDOUT)
for room in [502,519]:
    subprocess.Popen(['nsenter',f'--net=/run/netns/AP{room}','python','/lab/vlan_mux.py','eth0','50:eth1','99:q99'],stdout=open(f'/lab/mux-ap{room}.log','w'),stderr=subprocess.STDOUT)
time.sleep(.5)
ROOT.joinpath('project_id.txt').write_text(PROJECT)
ROOT.joinpath('nodes.json').write_text(json.dumps(api(f'/projects/{PROJECT}/nodes'),ensure_ascii=False,indent=2))
ROOT.joinpath('links.json').write_text(json.dumps(links,ensure_ascii=False,indent=2))
ROOT.joinpath('specs.json').write_text(json.dumps(specs,ensure_ascii=False,indent=2))

conf=['port=53','no-resolv','domain=vt.lab','local=/vt.lab/','address=/app.vt.lab/192.168.101.131','interface=eth0','bind-interfaces','dhcp-authoritative','log-dhcp','log-facility=/lab/evidence/dnsmasq.log','dhcp-leasefile=/lab/evidence/dnsmasq.leases','dhcp-range=192.168.101.128,static,255.255.255.240']
for vid,gw in vlans:
    if vid not in [102,104,119,120,20,50]:continue
    if vid==50:start,end,mask='192.168.101.66','192.168.101.90','255.255.255.224'
    elif vid==20:start,end,mask='192.168.101.10','192.168.101.50','255.255.255.192'
    else:
        base=int(gw.split('.')[-1].split('/')[0])-1
        start,end,mask=f'192.168.100.{base+10}',f'192.168.100.{base+49}','255.255.255.192'
    conf.extend([f'dhcp-range=set:v{vid},{start},{end},{mask},1h',f'dhcp-option=tag:v{vid},option:router,{gw.split("/")[0]}',f'dhcp-option=tag:v{vid},option:dns-server,192.168.101.130'])
for s in specs:
    if s['dhcp']:
        mac=json.loads(ns(s['name'],'ip','-j','link','show','dev','eth0'))[0]['address']
        conf.append(f'dhcp-host={mac},{s["address"].split("/")[0]},{s["name"]},1h')
ROOT.joinpath('dnsmasq.conf').write_text('\n'.join(conf)+'\n')
relay=['port=0','bind-interfaces','log-dhcp','log-facility=/lab/evidence/relay.log']
for vid,gw in vlans:
    if vid in [102,104,119,120,20,50]:relay.append(f'dhcp-relay={gw.split("/")[0]},192.168.101.130')
ROOT.joinpath('relay.conf').write_text('\n'.join(relay)+'\n')
ROOT.joinpath('evidence').mkdir(exist_ok=True)
ns('DHCP1','dnsmasq','--conf-file=/lab/dnsmasq.conf','--pid-file=/lab/dnsmasq.pid')
ns('R1','dnsmasq','--conf-file=/lab/relay.conf','--pid-file=/lab/relay.pid')
print(f'Created {len(nodes)} nodes and {len(links)} links; project {PROJECT}')
