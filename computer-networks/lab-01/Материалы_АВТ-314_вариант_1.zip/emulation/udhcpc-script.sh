#!/bin/sh
if [ "$1" = bound ] || [ "$1" = renew ]; then
    ip addr flush dev "$interface"
    case "$subnet" in
        255.255.255.192) prefix=26;;
        255.255.255.224) prefix=27;;
        *) exit 1;;
    esac
    ip addr add "$ip/$prefix" dev "$interface"
    ip route replace default via "${router%% *}" dev "$interface"
fi
exit 0
