import socket, sys
mode, protocol, port = sys.argv[1], sys.argv[2], int(sys.argv[3])
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM if protocol == 'udp' else socket.SOCK_STREAM)
sock.settimeout(3 if mode == 'client' else None)
if mode == 'server':
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('0.0.0.0', port))
    if protocol == 'udp':
        while True:
            data, peer = sock.recvfrom(1024)
            sock.sendto(b'ACK:' + data, peer)
    else:
        sock.listen(8)
        while True:
            conn, peer = sock.accept()
            with conn:
                conn.sendall(b'ACK:' + conn.recv(1024))
else:
    try:
        sock.connect(('192.168.101.131', port))
        sock.sendall(b'VT-LAB1')
        print(sock.recv(1024).decode())
    except OSError as err:
        print(type(err).__name__ + ': ' + str(err))
    finally:
        sock.close()
