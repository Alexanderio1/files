import subprocess, json, time, signal
from pathlib import Path

ROOT=Path('/lab');E=ROOT/'evidence';E.mkdir(exist_ok=True)
results={}
def command(n,args,timeout=20):
    p=subprocess.run(['nsenter',f'--net=/run/netns/{n}']+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
    return {'returncode':p.returncode,'output':p.stdout}
def background(n,args,log):
    return subprocess.Popen(['nsenter',f'--net=/run/netns/{n}']+args,stdout=open(log,'w'),stderr=subprocess.STDOUT)
def capture(n,name):
    p=background(n,['tcpdump','--immediate-mode','-U','-n','-s','0','-i','eth0','-w',str(E/(name+'.pcap'))],E/(name+'-capture.log'))
    time.sleep(.2);return p
def stop(p):
    p.send_signal(signal.SIGINT)
    try:p.wait(3)
    except subprocess.TimeoutExpired:p.terminate();p.wait(3)
def save(k,data):
    results[k]=data;E.joinpath(k+'.txt').write_text(data['output']);print(k,data['returncode'],data['output'].strip(),flush=True)

caps=[capture('PC502A','01-dhcp'),capture('R1','01-dhcp-trunk'),capture('DHCP1','01-dhcp-server')]
save('01-dhcp',command('PC502A',['busybox','udhcpc','-B','-i','eth0','-s','/lab/udhcpc-script.sh','-n','-q','-t','4','-T','2']))
time.sleep(.5)
for p in caps:stop(p)
for s in json.loads(ROOT.joinpath('specs.json').read_text()):
    if s['dhcp'] and s['name']!='PC502A':
        save('dhcp-'+s['name'],command(s['name'],['busybox','udhcpc','-B','-i','eth0','-s','/lab/udhcpc-script.sh','-n','-q','-t','3','-T','2']))
save('address-PC502A',command('PC502A',['ip','-4','addr','show','dev','eth0']))
save('route-PC502A',command('PC502A',['ip','route','show']))

for name,target in [('02-ping-local','192.168.100.2'),('03-ping-unused','192.168.100.60'),('04-ping-gateway','192.168.100.1'),('05-ping-remote','192.168.101.131')]:
    command('PC502A',['ip','neigh','flush','all'])
    for dev in ['r102','r40']:command('R1',['ip','neigh','flush','dev',dev])
    command('APP1',['ip','neigh','flush','all'])
    caps=[capture('PC502A',name)]
    if name=='05-ping-remote':caps.append(capture('APP1',name+'-server'))
    save(name,command('PC502A',['ping','-c','3','-i','0.25','-W','2',target],timeout=15))
    time.sleep(.3)
    for p in caps:stop(p)

cap=capture('WIFI502','06-ping-wifi')
save('06-ping-wifi',command('WIFI502',['ping','-c','3','-i','0.25','-W','2','192.168.101.131']))
stop(cap)
for protocol,port,prefix in [('udp',9000,'07-udp'),('tcp',8000,'09-tcp')]:
    server=background('APP1',['python','/lab/transport.py','server',protocol,str(port)],E/(prefix+'-server.log'))
    time.sleep(.3)
    cap=capture('PC502A',prefix+'-open')
    save(prefix+'-open',command('PC502A',['python','/lab/transport.py','client',protocol,str(port)]))
    time.sleep(.3);stop(cap)
    server.terminate();server.wait(3)
    name='08-udp-closed' if protocol=='udp' else '10-tcp-closed'
    cap=capture('PC502A',name)
    save(name,command('PC502A',['python','/lab/transport.py','client',protocol,str(port)]))
    time.sleep(.3);stop(cap)

ROOT.joinpath('results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
for p in E.glob('*.pcap'):
    args=['tshark','-r',str(p),'-n','-o','tcp.relative_sequence_numbers:TRUE']
    out=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True).stdout
    E.joinpath(p.stem+'-packets.txt').write_text(out)
print('Experiments complete',flush=True)
