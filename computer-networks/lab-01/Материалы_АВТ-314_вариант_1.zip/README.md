# Лабораторная работа № 1 — АВТ-314, вариант 1

Проект сети ВТ на пятом этаже VII корпуса НГТУ, 172 устройства.

## Состав

- `configs/` — проектные конфигурации семи коммутаторов Eltex, ESR-31 и двух WEP-3ax. Перед применением заменить `<ADMIN_SECRET>` и `<WIFI_SECRET>`.
- `evidence/` — 13 реальных захватов PCAP, вывод программ, расшифровки tshark и журналы DHCP. TCP Seq/Ack в текстовых расшифровках относительные.
- `emulation/` — исполнявшиеся программы и настройки стенда; `nodes.json`, `links.json`, `project.gns3`, `results.json`, `evidence_metrics.json`.
- `assets/` — чистовой план этажа в PNG/PDF и снимок работающего GNS3 Web UI.

Конфигурации Eltex проектные и на физических Eltex не исполнялись. Эксперименты выполнялись в GNS3 Server 2.2.55 / Web UI 2.2.54, Dynamips 0.2.23, uBridge 0.9.19, Linux, dnsmasq 2.90, BusyBox udhcpc 1.35.0 и Python 3.11.

## Запуск стенда

Нужен Linux с Docker, поддержкой сетевых пространств имён и разрешением создавать veth. Выполняйте в отдельной учебной среде. Ниже создаётся контейнер с привилегиями для виртуальных интерфейсов; реальные сетевые устройства не настраиваются. Каталог `emulation/` используется как `/lab`.

```bash
docker build -t lab-avt314-v1 emulation
docker run -d --name lab-avt314-v1 --privileged \
  -p 127.0.0.1:3080:3080 \
  --mount type=bind,src="$PWD/emulation",dst=/lab lab-avt314-v1
docker exec lab-avt314-v1 sh -c \
  'gns3server --host 0.0.0.0 --port 3080 --local --allow > /lab/gns3server.log 2>&1 &'
```

После успешного ответа `GET http://127.0.0.1:3080/v2/version`:

```bash
docker exec lab-avt314-v1 python /lab/setup.py
docker exec lab-avt314-v1 python /lab/experiments.py
docker exec lab-avt314-v1 python /lab/extract_metrics.py
docker exec lab-avt314-v1 chmod -R a+rX /lab/evidence
```

Откройте `http://127.0.0.1:3080/`, затем проект `AVT-314 Lab1 V1 VT 172 nodes`. Новые PCAP и журналы сохранятся в `emulation/evidence/`. Исходные материалы выполненной работы находятся отдельно в `evidence/` архива. `setup.py` создаёт новый UUID проекта и связывает Cloud-адаптеры с локальными veth. Один файл `project.gns3` без этих интерфейсов не восстанавливает работающий стенд.

При корпоративном HTTPS-прокси передайте доверенный CA без отключения проверки TLS:

```bash
docker build --secret id=proxy_ca,src=/path/to/trusted-ca-bundle.pem \
  -t lab-avt314-v1 emulation
```

`vlan_mux.py` прозрачно добавляет/удаляет тег 802.1Q между trunk и интерфейсами VLAN маршрутизатора/AP. Это адаптер для ядра без модульных VLAN-интерфейсов; сам IPv4/ARP/ICMP/UDP/TCP обрабатывается Linux. На veth отключена разгрузка контрольных сумм, чтобы захваты и передача через raw Ethernet были корректны. Два узла AIR — прозрачные соединители для логического Wi-Fi, а не дополнительные реальные коммутаторы. Радиоэфир и WPA2 не моделируются.

Для остановки и удаления только созданного стенда:

```bash
docker stop lab-avt314-v1
docker rm lab-avt314-v1
```

## Проверка результатов

`extract_metrics.py` проверяет DORA, три положительных обязательных ping и Wi-Fi ping (по три Echo Reply), ICMP type 3 code 3 и TCP RST/ACK. `results.json` содержит фактический вывод программ, `evidence_metrics.json` — поля пакетов. PCAP можно открыть в Wireshark; фильтры: `dhcp`, `arp`, `icmp`, `udp.port == 9000`, `tcp.port == 8000`.

План перерисован по фотографии пользователя. Масштаб условный. Метраж, реальная вместимость помещений и радиопокрытие требуют измерений.
